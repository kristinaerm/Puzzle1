Npgsql - .NET Data Provider for PostgreSQL
=============

[![Stable nuget](https://img.shields.io/nuget/v/Npgsql.svg?label=stable%20nuget)](https://www.nuget.org/packages/Npgsql/)
![Unstable nuget](https://img.shields.io/myget/npgsql-unstable/v/npgsql.svg?label=unstable%20nuget)
[![Build Status](https://img.shields.io/teamcity/http/build.npgsql.org/s/npgsql_CompileReleaseAndPush.svg?label=TeamCity)](http://build.npgsql.org/viewType.html?buildTypeId=npgsql_CompileReleaseAndPush&guest=1) [![Join the chat at https://gitter.im/npgsql/npsgl](https://img.shields.io/badge/GITTER-JOIN%20CHAT-brightgreen.svg)](https://gitter.im/npgsql/npgsql)

### What Is Npgsql?

Npgsql is a .NET data provider for PostgreSQL. It allows you to connect and interact with PostgreSQL server using .NET.

For any additional information, please visit the Npgsql website at [http://www.npgsql.org](http://www.npgsql.org).
